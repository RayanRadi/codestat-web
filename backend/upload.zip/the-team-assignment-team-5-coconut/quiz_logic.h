#ifndef QUIZ_LOGIC_H
#define QUIZ_LOGIC_H

// Function to start the quiz for a given category
void start_quiz(char category_name[]);

#endif // QUIZ_LOGIC_H
