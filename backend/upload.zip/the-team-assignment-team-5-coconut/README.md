# Flashcard App

## Introduction

This Flashcard App is a simple command-line program written in C. It allows you to create categories, add flashcards to those categories, and quiz yourself on them. The code avoids advanced C concepts, making it suitable for beginners.

## Features

- **Add Categories**: Organize your flashcards by grouping them into different categories.
- **Add Flashcards**: Create questions and answers within your chosen categories.
- **Start Quizzes**: Test your knowledge by taking a quiz in any category you've created.


